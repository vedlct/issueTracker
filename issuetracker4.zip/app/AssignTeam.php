<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssignTeam extends Model
{
    protected $table='assignteam_new';
    protected $primaryKey='id';
    public $timestamps=false;
}

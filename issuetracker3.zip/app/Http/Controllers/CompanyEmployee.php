<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CompanyEmployee extends Controller
{
    //
}

<?php

define('ACCOUNT_STATUS',array(
    "Debit"=>'debit',
    "Credit"=>'credit'
));

define('USER_TYPE',array(
    "Admin"=>'admin',
    "CableEmp"=>'CableEmp',
    "InternetEmp"=>'InternetEmp',

));
define('BANDWIDTH_TYPE',array(
    "1"=>'Real',
    "2"=>'Share',
    "3"=>'Dynamic Ip'
));

define('CONNECTION_TYPE',array(
    "1"=>'Fiber',
    "2"=>'Utp',
    "3"=>'Cable'
));
define('CONNECTION_FIBER',array(
    "1"=>'onu',
    "2"=>'mc',
    "3"=>'mac'
));

define('CONNECTION_UTP',array(
    "1"=>'cat-5',
    "2"=>'cat-6'
));

define('USER_STATUS',array(
    "1"=>'inactive',
    "2"=>'active',
    "3"=>'free',
));
define('OTHERS',"Others");








